/** Automatically generated file. DO NOT MODIFY */
package org.steamzone.tweentest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}